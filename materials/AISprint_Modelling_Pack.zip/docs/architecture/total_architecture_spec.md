# Project Briefly: Total Technical Architecture (HLD & LLD)

This document provides the exhaustive technical blueprint for the Briefly platform. It covers every node, database schema, and agentic state transition to the minute detail.

---

## 1. High-Level Design (HLD): Global Topology

The system is designed for **CP (Consistency & Partition Tolerance)** at the core, with **AP (Availability & Partition Tolerance)** at the read-edge.

```mermaid
graph TD
    User["User (Agency/Client)"] -- "HTTPS (Brotli)" --> CF["Cloudflare Edge (WAF + R2)"]
    CF -- "Pre-signed URL" --> R2["Cloudflare R2 (Media Storage)"]
    CF -- "Rate-Limited Traffic" --> Nginx["Nginx (SSE Un-buffering)"]
    Nginx -- "Proxy Pass" --> Go["Go API (Gin + GORM)"]
    
    subgraph Persistence
        Go -- "ACID Transactions" --> PG[("PostgreSQL (JSONB + GIN Index)")]
        Go -- "Read-Through Cache" --> Redis[("Redis (Queue + Cache)")]
    end
    
    subgraph "AI Engine"
        Redis -- "BRPOP (Blocking Poll)" --> Worker["Python Worker (LangGraph)"]
        Worker -- "Parallel Async" --> Whisper["OpenAI Whisper"]
        Worker -- "Parallel Async" --> Vision["GPT-4o Vision"]
        Worker -- "Llama-3 Synthesis" --> Groq["Groq API"]
        Worker -- "Failover" --> Ollama["Local Ollama"]
    end
    
    Worker -- "State Update" --> PG
    Worker -- "Event Publish" --> Redis
    Redis -- "SSE Push" --> Go
    Go -- "EventStream" --> User
```

---

## 2. Low-Level Design (LLD): Data Persistence (Postgres)

We utilize a **Hybrid Normalized/Document** schema to balance ACID stability with AI flexibility.

```mermaid
erDiagram
    USERS ||--o{ INTAKES : creates
    INTAKES ||--|| BRIEFS : generates
    BRIEFS ||--o{ FEEDBACK : receives

    INTAKES {
        uuid id PK
        uuid agency_id FK
        string type "audio | text | hybrid"
        string status "PENDING | PROCESSING | COMPLETED | FAILED"
        string raw_text
        string media_url "R2 Pre-signed URL"
        int retry_count
    }

    BRIEFS {
        uuid id PK
        uuid intake_id FK
        jsonb goals "GIN Indexed"
        jsonb ambiguities "GIN Indexed"
        jsonb tone_profile
        timestamp created_at
    }
```

---

## 3. Low-Level Design (LLD): The Agentic Pipeline (LangGraph)

The AI worker is a resilient state machine with parallel fan-out and idempotent nodes.

```mermaid
graph LR
    Start((Queue Receive)) --> Ingest["Node: Ingest (Sanitize)"]
    Ingest --> Transcribe["Node: Transcribe (Async Whisper)"]
    Ingest --> OCR["Node: Vision (Async OCR)"]
    
    Transcribe --> Merge["Node: Context Merge"]
    OCR --> Merge
    
    Merge --> Analyze["Node: Analyze (Llama-3 Reasoning)"]
    Analyze --> Ambiguity["Node: Ambiguity Check"]
    Ambiguity --> Tone["Node: Tone Mapper"]
    
    Tone --> Finalize["Node: Finalize (SSE & DB Write)"]
    Finalize --> End((Job Complete))

    %% Error Path
    Analyze -- "Rate Limit / 429" --> Ollama["Fallback: Local Ollama"]
    Ollama --> Ambiguity
```

---

## 4. Low-Level Design (LLD): API Sequence & SSE Lifecycle

This details the sub-second interaction between the client and the backend during an intake submission.

```mermaid
sequenceDiagram
    participant C as Client (React)
    participant A as Go API (Gin)
    participant R as Redis (Queue)
    participant W as Python Worker
    
    C->>A: POST /api/v1/intake (Metadata)
    A->>C: 202 Accepted {intake_id, upload_url}
    C->>A: GET /api/v1/events/{id} (SSE Connection)
    A-->>C: event: connected
    
    C->>A: POST /api/v1/intake/confirm
    A->>R: LPUSH intake:queue {payload}
    R->>W: BRPOP
    W->>W: Processing...
    W->>R: PUBLISH event:intake:{id} "NODE_TRANSCRIBE_DONE"
    R-->>A: Received Event
    A-->>C: data: NODE_TRANSCRIBE_DONE
    
    W->>W: Finalize
    W->>R: PUBLISH event:intake:{id} "COMPLETED"
    A-->>C: data: COMPLETED
```

---

## 5. Non-Functional Requirements (Performance & Security)

| Requirement | Implementation Detail |
| :--- | :--- |
| **Throughput** | 250 RPS target via Go M:N concurrency. |
| **Memory Tuning** | `GOGC=200` to optimize for large Oracle ARM RAM. |
| **Ingress Security** | Cloudflare WAF Token Bucket (60 req/min). |
| **Real-time SSE** | Nginx `proxy_buffering off` to prevent stream chunking. |
| **Failover** | Circuit Breaker fallback to Ollama Llama-3. |

---

## 📋 Handoff Cookbooks
- [**DevOps Master Manifesto**](file:///home/qwerty/aisprint/cookbooks/devops_cookbook.md)
- [**Go Backend Cookbook**](file:///home/qwerty/aisprint/cookbooks/backend_cookbook.md)
- [**AI/Python Cookbook**](file:///home/qwerty/aisprint/cookbooks/ai_cookbook.md)
- [**Frontend Cookbook**](file:///home/qwerty/aisprint/cookbooks/frontend_cookbook.md)
