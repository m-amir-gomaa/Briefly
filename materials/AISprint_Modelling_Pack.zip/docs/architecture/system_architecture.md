# Comprehensive System Architecture: Project Briefly

This document provides a high-detail, zoomable architectural blueprint of the Briefly system. It maps every component, data structure, and interaction identified during the deep analysis.

---

## 1. System Topology & Deployment (C4-Style)
This diagram represents the physical and logical boundaries of the system, including network routing and inter-service dependencies.

```mermaid
graph TD
    subgraph Client_Layer [Client Layer]
        Browser["🌐 Web Browser (React/Vite)"]
    end

    subgraph Entry_Point [Entry Point & Routing]
        Nginx["📦 Nginx Reverse Proxy (Port 80)"]
    end

    subgraph Application_Layer [Application Layer]
        Go_API["🚀 Go Backend API (Port 8080)"]
        AI_Worker["🧠 Python AI Worker (Port 8001)"]
    end

    subgraph Data_Layer [Data & Messaging Layer]
        Postgres[("🐘 PostgreSQL 16 (Persistence)")]
        Redis[("⚡ Redis 7 (Queue & Events)")]
    end

    subgraph External_APIs [External Intelligence]
        Whisper["🎙️ OpenAI Whisper (Transcription)"]
        GPT_Vision["👁️ GPT-4o Vision (OCR/Image Analysis)"]
        Llama["🦙 Groq/Llama-3 (Text Analysis)"]
    end

    %% Routing
    Browser -- "HTTP / (Static/Vite)" --> Nginx
    Browser -- "HTTP /api/* (JSON)" --> Nginx
    Browser -- "EventSource /api/v1/events/* (SSE)" --> Nginx
    Nginx -- "Proxy Pass :8080" --> Go_API

    %% Backend Interactions
    Go_API -- "GORM (DSN)" --> Postgres
    Go_API -- "LPush (intake:queue)" --> Redis
    Go_API -- "Subscribe (intake:events:{id})" --> Redis

    %% AI Worker Interactions
    AI_Worker -- "BRPop (intake:queue)" --> Redis
    AI_Worker -- "Publish (intake:events:{id})" --> Redis
    AI_Worker -- "PATCH /api/v1/intake/{id}" --> Go_API
    
    %% AI Intelligence Flow
    AI_Worker -- "STT Request" --> Whisper
    AI_Worker -- "Vision Request" --> GPT_Vision
    AI_Worker -- "Extraction Request" --> Llama

    %% Styling
    style Nginx fill:#232F3E,color:#fff
    style Go_API fill:#00ADD8,color:#fff
    style AI_Worker fill:#3776AB,color:#fff
    style Postgres fill:#336791,color:#fff
    style Redis fill:#D82C20,color:#fff
```

---

## 2. Detailed Data Models (LLD Class Diagram)
This diagram contains every field, relationship, and type used in the backend and AI worker state.

```mermaid
classDiagram
    class User {
        +UUID id
        +String email
        +String agency_name
        +String password_hash
        +DateTime created_at
        +DateTime updated_at
    }

    class Intake {
        +UUID id
        +UUID user_id
        +IntakeType type
        +String raw_text
        +String audio_url
        +String image_url
        +IntakeStatus status
        +Int retry_count
        +DateTime created_at
        +DateTime updated_at
    }

    class Brief {
        +UUID id
        +UUID intake_id
        +String summary
        +JSONB goals
        +JSONB success_criteria
        +JSONB ambiguities
        +JSONB followup_questions
        +JSONB evidence_map
        +String cot_log
        +Float confidence_score
        +String tone_profile
        +String share_token
        +Boolean is_confirmed
        +DateTime confirmed_at
        +String client_name
    }

    class ShipmentState {
        <<Python TypedDict>>
        +String intake_id
        +String type
        +String raw_text
        +String audio_url
        +String image_url
        +String transcription
        +String ocr_text
        +String unified_context
        +String summary
        +List goals
        +List success_criteria
        +List ambiguities
        +List followup_questions
        +Dict evidence_map
        +String cot_log
        +Float confidence_score
        +String tone_profile
    }

    User "1" *-- "many" Intake : owns
    Intake "1" -- "1" Brief : generates
    Brief "1" *-- "many" Feedback : receives
    
    class IntakeType {
        <<enumeration>>
        TEXT
        VOICE
        IMAGE
        MULTI
    }

    class IntakeStatus {
        <<enumeration>>
        PENDING
        PROCESSING
        COMPLETED
        FAILED
    }
```

---

## 3. AI Agentic Workflow (LangGraph State Machine)
The internal logic of the `ai_worker`, showing every decision branch and state mutation.

```mermaid
stateDiagram-v2
    [*] --> Ingest
    
    Ingest --> Transcribe : if audio_url exists
    Ingest --> Vision : if image_url exists
    Ingest --> Merge : if text only
    
    Transcribe --> Merge
    Vision --> Merge
    
    state Merge {
        [*] --> Combine_Context
        Combine_Context --> Unified_String
    }
    
    Merge --> Analyze
    
    state Analyze {
        [*] --> LLM_Extraction
        LLM_Extraction --> Summary_Mapping
        Summary_Mapping --> Goals_Mapping
    }
    
    Analyze --> Ambiguity_Detection
    
    state Ambiguity_Detection {
        [*] --> Scan_Gaps
        Scan_Gaps --> Generate_Questions
    }
    
    Ambiguity_Detection --> Tone_Mapping
    Tone_Mapping --> Finalize
    
    Finalize --> [*] : Publish Redis Event
```

---

## 4. End-to-End Behavioral Flow (Sequence Diagram)
The lifecycle of a single brief, from user interaction to real-time client notification.

```mermaid
sequenceDiagram
    autonumber
    participant Client as 🌐 Frontend (React)
    participant Nginx as 📦 Nginx
    participant API as 🚀 Go Backend
    participant DB as 🐘 Postgres
    participant Redis as ⚡ Redis
    participant AI as 🧠 AI Worker

    Note over Client, AI: Intake Phase
    Client->>Nginx: POST /api/v1/intake (Multipart Form)
    Nginx->>API: Proxy Request
    API->>DB: INSERT INTO intakes (status='PENDING')
    API->>Redis: LPUSH intake:queue {payload}
    API-->>Client: 202 Accepted (intake_id)

    Note over Client, AI: Processing Phase
    Client->>Nginx: GET /api/v1/events/{id} (SSE)
    Nginx->>API: Establish Stream
    API->>Redis: SUBSCRIBE intake:events:{id}

    AI->>Redis: BRPOP intake:queue
    AI->>AI: Execute LangGraph Pipeline
    AI->>API: PATCH /api/v1/intake/{id} (Results)
    API->>DB: INSERT INTO briefs + UPDATE status='COMPLETED'
    API->>Redis: PUBLISH intake:events:{id} "COMPLETED"
    
    Note over Client, AI: Completion Phase
    Redis-->>API: PubSub Notification
    API-->>Client: SSE Event: COMPLETED
    Client->>Nginx: GET /api/v1/intake/{id}
    API-->>Client: 200 OK (Full Brief Data)
```

---

## 5. Network & Security Layer (Infrastructure)
Detailed port mapping and security boundary definition.

| Protocol | Source | Destination | Component | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| **HTTP** | External | Nginx:80 | Entry Point | Public Access |
| **HTTP** | Nginx | Go_API:8080 | Reverse Proxy | API Routing |
| **TCP** | Go_API | Postgres:5432 | Database | Persistence |
| **TCP** | Go_API | Redis:6379 | PubSub/Queue | Messaging |
| **TCP** | AI_Worker | Redis:6379 | BRPop/Publish | Task Consumption |
| **HTTP** | AI_Worker | Go_API:8080 | Callback | Result Submission |
| **HTTPS** | AI_Worker | External | OpenAI/Groq | LLM Intelligence |

> [!TIP]
> **Zoomable View**: This diagram is rendered using Mermaid.js. You can zoom in on specific nodes to see field definitions and relationship cardinality.
