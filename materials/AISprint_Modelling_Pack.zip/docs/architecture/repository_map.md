# Project Briefly: Repository Map & Rationale

You asked: **"Why do we have code?"** 

In a high-stakes hackathon, design diagrams are just paper. To ensure the **System Design Principles** we spent hours debating are actually followed, we have implemented **Architectural Scaffolding**.

This code isn't the final "Business Logic"—it's the **Enforcement Layer**. It defines the boundaries, the data types, and the communication protocols. Without this code, the first thing your teammates would do is build a monolithic app that blocks the main thread, uses an unindexed database, and leaks memory. This scaffolding forces them to build it correctly from Minute 1.

---

## 📂 Repository Structure

### 🏗️ `/infra` (The Foundation)
*   **`nginx/`**: Contains the traffic-shaping rules. This is where we disabled buffering for SSE to ensure real-time "wow factor".
*   **`secrets/`**: The skeleton for `sops-nix`. This ensures your team never accidentally commits an API key to the repo.
*   **`nixos/`**: The declarative server config. This makes our Oracle VPS "disposable" and reproducible.

### ⚙️ `/backend` (The Brain-Stem - Go)
*   **`cmd/api/main.go`**: The entry point. It enforces the **Graceful Shutdown** and **GOGC=200** tuning we decided on.
*   **`internal/models/`**: The strict data contract. It mandates the use of **JSONB** for AI outputs, preventing schema-migration delays.
*   **`internal/db/`**: Handles the connection pooling logic (`SetMaxOpenConns`) to protect our free-tier database.
*   **`migrations/`**: The SQL source of truth. It contains the **GIN Index** for fast brief searching.

### 🤖 `/ai_service` (The Computational Engine - Python)
*   **`main.py`**: The Redis worker. It polls the queue and ensures jobs are processed asynchronously.
*   **`agents/orchestrator.py`**: The **LangGraph State Machine**. This enforces the Fan-Out/Fan-In topology and the **Idempotency Check** to save us money on API calls.
*   **`requirements.txt`**: Locks the versions of Whisper, Groq, and LangGraph.

### 🎨 `/frontend` (The Client - React/Vite)
*   **`src/store/`**: Contains the **Zustand** stores. This enforces a lightweight state model over heavy Redux.
*   **`src/views/`**: Scaffolding for the Dashboard, Intake, and Public Brief. These are tied to the CSS/Tailwind configs that match our high-fidelity mockups.

### 📖 `/cookbooks` (The Team Manuals)
*   These are the "Playbooks" for your teammates. They explain how to use AI to build their specific part *within* the guardrails of the repo structure above.

---

## 🛠️ The DevOps Dominance
The **DevOps Cookbook** has been upgraded to a **Master Manifesto**. It focuses on the three pillars of a 1st place project:
1. **Security**: Cloudflare WAF + Sops-nix.
2. **Performance**: R2 Pre-Signed URLs + Nginx SSE tuning.
3. **Reproducibility**: NixOS Flakes.

**The repo is now a locked, ready-to-run environment. Your team just needs to fill in the "brains" of each node.**
