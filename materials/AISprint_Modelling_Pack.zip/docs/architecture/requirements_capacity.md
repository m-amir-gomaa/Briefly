# Project Briefly: Master Technical Specification

This document serves as the formal "Contract" for the system. It defines the operational boundaries and success metrics for the Briefly platform.

## 1. Rigorous Capacity Modelling (The Stats)

These figures are derived from our target load of 250 Requests Per Second (RPS) and the constraints of the Oracle Cloud Free Tier.

| Metric | Target Value | Rationale |
| :--- | :--- | :--- |
| **Peak Throughput** | 250 RPS | Supports ~15,000 concurrent active sessions. |
| **P99 API Latency** | < 150ms | Ensures the dashboard feels "instant" during intake creation. |
| **AI Ingestion Latency** | < 8s | Includes Whisper (3s) + Vision (4s) + Parallel Merge. |
| **Max Concurrent SSE** | 5,000 | Limited by Oracle VPS RAM (24GB) and Go Goroutine overhead. |
| **Storage Quota (R2)** | 10GB | Based on 25MB max upload and 7-day retention policy. |
| **Cache Hit Ratio** | > 85% | Read-through caching in Redis for public brief links. |

---

## 2. Functional Requirements (FR)

The system **MUST** perform the following actions:
- **FR-1: Multi-Modal Ingestion**: Support raw text, .mp3/.wav audio, and .jpg/.png screenshots in a single project intake.
- **FR-2: Agentic Synthesis**: Utilize a 7-node LangGraph pipeline to extract goals, success criteria, and ambiguities.
- **FR-3: Real-Time Status**: Stream pipeline progress (Node A -> Node B) to the Agency Dashboard via SSE.
- **FR-4: Living Document**: Generate a shareable, zero-auth URL for clients to view and "Sign Off" on the brief.
- **FR-5: Feedback Loop**: Allow clients to comment on specific extracted goals, triggering a re-generation of the brief.

---

## 3. Non-Functional Requirements (NFR)

The system **MUST** adhere to the following quality constraints:
- **NFR-1: Scalability**: The Go API must handle 250 RPS on 4 OCPU ARM without horizontal scaling (Vertical efficiency).
- **NFR-2: Availability**: Implement 100% failover to local Ollama Llama-3 if external LLM APIs (Groq/OpenAI) are disrupted.
- **NFR-3: Security**: Zero-plaintext secret storage via `sops-nix` and Edge-level rate limiting via Cloudflare WAF.
- **NFR-4: Performance**: Optimize the Go runtime with `GOGC=200` to minimize GC pause times under load.
- **NFR-5: Compliance**: Ensure all client data is encrypted at rest in PostgreSQL using AES-256 (via `pgcrypto`).

---

## 4. Extended Requirements (ER)

Future-proofing for the Hackathon "Wow" Factor:
- **ER-1: Egyptian Localization**: Tone-mapping to detect and respond in Ammiya/Franco-Arab when necessary.
- **ER-2: WhatsApp Integration**: Generate a "Copy to WhatsApp" draft for every follow-up question the AI identifies.
- **ER-3: Offline-First**: Support local development and testing entirely through Docker without internet-dependent Cloudflare features.

---

## 5. Architecture Modelling (The Diagrams)

### Global Network Topology
```mermaid
graph TD
    Client((User/Client)) --> CF[Cloudflare Edge: WAF/CDN/R2]
    CF --> Nginx[Nginx Reverse Proxy: SSL/SSE-unbuffering]
    Nginx --> Go[Go Gin API: Auth/Routing/Logic]
    Go --> DB[(PostgreSQL: JSONB/GIN Index)]
    Go --> Redis[(Redis: Job Queue/Cache)]
    Redis <--> Python[Python Worker: LangGraph Agent]
    Python --> AI[AI APIs: OpenAI/Groq/Whisper]
    Python -- Fallback --> Ollama[Local Ollama: Llama-3]
```

### LangGraph Workflow
```mermaid
graph LR
    Start((Intake)) --> Ingest[node_ingest]
    Ingest --> Transcribe[node_transcribe: Whisper]
    Ingest --> Vision[node_vision: GPT-4o]
    Transcribe --> Merge[node_merge]
    Vision --> Merge
    Merge --> Analyze[node_analyze: Llama-3]
    Analyze --> Ambiguity[node_ambiguity]
    Ambiguity --> Tone[node_tone: Localization]
    Tone --> Finalize[node_finalize]
    Finalize --> End((SSE Push))
```
